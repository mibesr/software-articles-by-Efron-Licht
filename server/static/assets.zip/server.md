Computers nowdays are fast. Really fast. But websites and programs are slow.

I didn't want to 

## strategy 1:
- ask not what you can 