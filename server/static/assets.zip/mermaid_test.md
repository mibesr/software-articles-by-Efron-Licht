# mermaid test

![eating five batteries](./mermaid_test-1.svg "eating one battery")
